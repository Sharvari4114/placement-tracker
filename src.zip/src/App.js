import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pie } from 'react-chartjs-2';
import './App.css';

import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

function App() {

  const [page, setPage] = useState("form");

  const [form, setForm] = useState({
    topic: '',
    status: '',
    mistake: '',
    timeTaken: ''
  });

  const [analysis, setAnalysis] = useState({});
  const [goal, setGoal] = useState(100);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submitData = async () => {

    if (form.status === "Solved") {
      form.mistake = "No Mistake";
    }

    await axios.post('http://localhost:5000/api/add', form);

    alert(form.status === "Solved" ? "🎉 Great job!" : "💪 Keep trying!");

    fetchAnalysis();
  };

  const fetchAnalysis = async () => {
    const res = await axios.get('http://localhost:5000/api/analysis');
    setAnalysis(res.data);
  };

  useEffect(() => {
    fetchAnalysis();
  }, []);

  const pieData = {
    labels: analysis.topicCount ? Object.keys(analysis.topicCount) : [],
    datasets: [
      {
        data: analysis.topicCount ? Object.values(analysis.topicCount) : [],
        backgroundColor: [
          '#ff6384',
          '#36a2eb',
          '#ffce56',
          '#4ade80',
          '#f97316'
        ]
      }
    ]
  };

  return (
    <div className="container">

      <h1>🚀 Placement Tracker</h1>

      <div className="nav">
        <button onClick={() => setPage("form")}>➕ Add Entry</button>
        <button onClick={() => setPage("dashboard")}>📊 Dashboard</button>
        <button onClick={() => setPage("analysis")}>⚠ Analysis</button>
      </div>

      {/* FORM */}
      {page === "form" && (
        <div className="card">
          <h2>Add Entry</h2>

          <input name="topic" placeholder="Topic" onChange={handleChange} />

          <select name="status" onChange={handleChange}>
            <option>Status</option>
            <option>Solved</option>
            <option>Unsolved</option>
          </select>

          <select name="mistake" onChange={handleChange}>
            <option>Select Mistake</option>
            <option>No Mistake</option>
            <option>Concept</option>
            <option>Logic</option>
            <option>Syntax</option>
            <option>Time</option>
            <option>Recursion</option>
          </select>

          <input type="number" name="timeTaken" placeholder="Time" onChange={handleChange} />

          <button onClick={submitData}>Submit</button>
        </div>
      )}

      {/* DASHBOARD */}
      {page === "dashboard" && (
        <div className="card">
          <h2>📊 Dashboard</h2>

          <p>🎯 Goal: {analysis.total || 0} / {goal}</p>
          <p>🔥 Streak: {analysis.streak || 0} days</p>

          <h3>📊 Topic Distribution</h3>

          {analysis.topicCount && Object.keys(analysis.topicCount).length > 0
            ? (
              <div style={{ width: "300px", height: "300px", margin: "20px auto" }}>
                <Pie
                  data={pieData}
                  options={{ responsive: true, maintainAspectRatio: false }}
                />
              </div>
            )
            : <p>No data available</p>
          }

          <h3>🏆 Achievements</h3>
          {analysis.total >= 5 && <p>🎯 Beginner</p>}
          {analysis.total >= 10 && <p>🔥 Consistent</p>}
          {analysis.total >= 20 && <p>💪 Strong</p>}
        </div>
      )}

      {/* ANALYSIS */}
      {page === "analysis" && (
        <div className="card">

          <h2>⚠ Weak Topics</h2>
          {analysis.weak && analysis.weak.map((w, i) => (
            <div key={i} className="weak-box">
              <h3>{w.topic}</h3>
              <p>{w.accuracy}%</p>
              <p>Issue: {w.mainIssue}</p>
              <p>{w.suggestion}</p>
            </div>
          ))}

          <h2>✅ Strong Topics</h2>
          {analysis.strong && analysis.strong.map((t, i) => (
            <p key={i}>✔ {t}</p>
          ))}

        </div>
      )}

    </div>
  );
}

export default App;