const express = require('express');
const router = express.Router();
const Entry = require('../models/Entry');

// ADD ENTRY
router.post('/add', async (req, res) => {
    try {
        const newEntry = new Entry(req.body);
        await newEntry.save();
        res.json({ message: "Saved" });
    } catch (err) {
        res.status(500).json(err);
    }
});

// ANALYSIS
router.get('/analysis', async (req, res) => {

    const data = await Entry.find();

    let topicMap = {};
    let dailyMap = {};
    let topicCount = {};
    let streakSet = new Set();

    data.forEach(e => {

        // Topic count (for Pie Chart)
        topicCount[e.topic] = (topicCount[e.topic] || 0) + 1;

        // Topic analysis
        if (!topicMap[e.topic]) {
            topicMap[e.topic] = { total: 0, solved: 0, mistakes: {} };
        }

        topicMap[e.topic].total++;

        if (e.status === "Solved") {
            topicMap[e.topic].solved++;
        }

        // Ignore "No Mistake"
        if (e.mistake && e.mistake !== "No Mistake") {
            topicMap[e.topic].mistakes[e.mistake] =
                (topicMap[e.topic].mistakes[e.mistake] || 0) + 1;
        }

        // Daily progress
        let date = new Date(e.date).toLocaleDateString();
        dailyMap[date] = (dailyMap[date] || 0) + 1;

        // Streak
        streakSet.add(new Date(e.date).toDateString());
    });

    let weak = [];
    let strong = [];

    for (let topic in topicMap) {
        let obj = topicMap[topic];
        let acc = (obj.solved / obj.total) * 100;

        let mistakes = obj.mistakes;
        let topMistake = Object.keys(mistakes).length > 0
            ? Object.keys(mistakes).reduce((a, b) =>
                mistakes[a] > mistakes[b] ? a : b)
            : "None";

        if (acc < 50) {
            weak.push({
                topic,
                accuracy: acc.toFixed(2),
                mainIssue: topMistake,
                suggestion: "Practice basics of " + topic
            });
        }

        if (acc >= 70) {
            strong.push(topic);
        }
    }

    let solvedCount = data.filter(e => e.status === "Solved").length;

    res.json({
        weak,
        strong,
        dailyMap,
        topicCount,   // ✅ for pie chart
        streak: streakSet.size,
        total: solvedCount
    });
});

module.exports = router;