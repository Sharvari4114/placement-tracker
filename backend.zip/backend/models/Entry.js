const mongoose = require('mongoose');

const entrySchema = new mongoose.Schema({
    topic: String,
    status: String,
    mistake: String,
    timeTaken: Number,
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Entry', entrySchema);