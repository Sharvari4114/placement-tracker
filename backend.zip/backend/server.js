const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api', require('./routes/temp'));

mongoose.connect('mongodb://127.0.0.1:27017/placementDB')
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

app.get('/', (req, res) => {
    res.send("Backend Working");
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});